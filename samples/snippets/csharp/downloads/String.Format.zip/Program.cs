﻿using System;
using System.Globalization;

class FormatExamples
{
    const int MAX_CHOICES = 10;

    static void Main()
    {
       do {
           var choice = GetSelection("");
 
           // Make sure this parses.
           int nChoice;
           bool result = Int32.TryParse(choice, out nChoice);
           
           if (! result) {
              string msg = $"'{choice}' is not a number between 0 and {MAX_CHOICES}.";
              GetSelection(msg);
           }

           if (nChoice < 1 || nChoice > MAX_CHOICES) {
              string msg = $"Your selection must be between 0 and {MAX_CHOICES}.";
              GetSelection(msg);
           }

            switch (nChoice)
            {
                case 0:
                    return;
                case 1:
                    GetStarted.Example1();
                    break;
                case 2:
                    GetStarted.Example2();
                    break;
                default:
                    break;
            
            }
            Console.Write("\nPress any key to continue...");
            Console.ReadKey(false);
        } while (true);
    } 

    private static string GetSelection(string msg)
    {
       Console.Clear();
       Console.WriteLine(" 1. Get Started: Insert an object into a string");
       Console.WriteLine(" 2. Get Started: Inserting a formatted object into a string");

       if (! String.IsNullOrEmpty(msg))
          Console.WriteLine($"\n** {msg} **\n");

       Console.Write("\nEnter the number of the example you wish to run and press <Enter>, or 0 to Exit: ");
       var choice = Console.ReadLine(); 
       return choice;
    }


}