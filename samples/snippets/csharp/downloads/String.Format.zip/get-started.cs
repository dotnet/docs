using System;

public class GetStarted
{
    public static void Example1()
    {
        Decimal pricePerOunce = 17.36m;
        String s = String.Format("The current price is {0} per ounce.",
                                 pricePerOunce);
        Console.WriteLine(s);
        // Result: The current price is 17.36 per ounce.
    }

    public static void Example2()
    {
        Decimal pricePerOunce = 17.36m;
        String s = String.Format("The current price is {0:C2} per ounce.",
                                pricePerOunce);
        Console.WriteLine(s);
        // Result if current culture is en-US:
        //      The current price is $17.36 per ounce.
    } 

    public static void Example3()
    {
        decimal temp = 20.4m;
        string s = String.Format("The temperature is {0}°C.", temp);
        Console.WriteLine(s);
        // Displays 'The temperature is 20.4°C.'        
    }

    public static void Example4()
    {
        string s = String.Format("At {0}, the temperature is {1}°C.",
                                DateTime.Now, 20.4);
        Console.WriteLine(s);
        // Output similar to: 'At 4/10/2015 9:29:41 AM, the temperature is 20.4°C.'        
    }
}
