﻿using System;
using System.Collections.Generic;
using System.Globalization;

class FormatExamples
{
    const int MAX_CHOICES = 27;

    static void Main()
    {
       do {
           var choice = GetSelection("");
 
           // Make sure this parses.
           int nChoice;
           bool result = Int32.TryParse(choice, out nChoice);
           
           if (! result) {
              string msg = $"'{choice}' is not a number between 0 and {MAX_CHOICES}.";
              GetSelection(msg);
           }

           if (nChoice < 0 || nChoice > MAX_CHOICES) {
              string msg = $"Your selection must be between 0 and {MAX_CHOICES}.";
              GetSelection(msg);
           }
           Console.WriteLine();

            switch (nChoice)
            {
                case 0:
                    return;
                case 1:
                    GetStarted.Example1();
                    break;
                case 2:
                    GetStarted.Example2();
                    break;
                case 3:
                    GetStarted.Example3();
                    break;
                case 4:
                    GetStarted.Example4();
                    break;
                case 5:
                    GetStarted.Example5();
                    break;
                case 6:
                    GetStarted.Example6();
                    break;
                case 7:
                    GetStarted.Example7();
                    break;
                case 8:
                    FormatElements.FormatMethod();
                    break;
                case 9:
                    FormatElements.FormatItem();
                    break;
                case 10:
                    FormatElements.FormattedFormatItem();
                    break;
                case 11:
                    FormatElements.SameIndex();
                    break;
                case 12:
                    CustomerFormatterTest.Test();
                    break;
                case 13:
                    RomanNumeralExample.Test();
                    break;
                case 14:
                    QA.WithoutInterpolation();
                    break;
                case 15:
                    QA.DecimalDigits();
                    break;    
                case 16:
                    QA.DigitsUsingCustomFormatSpecifier();
                    break;
                case 17:
                    QA.IntegralDigits();
                    break;
                case 18:
                    QA.IntegralDigitsUsingCustom();
                    break;
                case 19:
                    QA.EscapedBraces();
                    break;
                case 20:
                    QA.BracesInFormatList();
                    break;
                case 21:
                    QA.FormatException();
                    break;
                case 22:
                    Examples.SingleArgument();
                    break;
                case 23:
                    Examples.TwoArguments();
                    break;
                case 24:
                    Examples.ThreeArguments();
                    break;
                case 25:
                    Examples.MoreThanThree_1();
                    break;
                case 26:
                    Examples.MoreThanThree_2();
                    break;
                case 27:
                    Examples.CultureSensitive();
                    break;
                default:
                    break;
            }
            Console.Write("\nPress any key to continue...");
            Console.ReadKey(false);
        } while (true);
    } 

    private static string GetSelection(string msg)
    {
       Console.Clear();
       Console.WriteLine(" 1. Get Started: Insert an object into a string");
       Console.WriteLine(" 2. Get Started: Inserting a formatted object into a string");
       Console.WriteLine(" 3. Get Started: Format item and object");
       Console.WriteLine(" 4. Get Started: 2 format items and 2 objects");
       Console.WriteLine(" 5. Get Started: Control formatting");
       Console.WriteLine(" 6. Get Started: Control spacing");
       Console.WriteLine(" 7: Get Started: Control alignment");
       Console.WriteLine(" 8: Format Elements: in brief");
       Console.WriteLine(" 9: Format Elements: format item");
       Console.WriteLine("10: Format Elements: Formatted format item");
       Console.WriteLine("11: Format Elements: Format items with the same index");
       Console.WriteLine("12: Custom Formatting: Customer account formatter");
       Console.WriteLine("13: Custom Formatting: Roman numeral formatter");
       Console.WriteLine("14: Q & A: String interpolation comparison");
       Console.WriteLine("15: Q & A: Digits after the decimal separator");
       Console.WriteLine("16: Q & A: Digits after the decimal separator with custom format string");
       Console.WriteLine("17: Q & A: Integral digits");
       Console.WriteLine("18: Q & A: Integral digits with a custom format string"); 
       Console.WriteLine("19: Q & A: Escaped braces");
       Console.WriteLine("20: Q & A: Braces in a format list");
       Console.WriteLine("21: Q & A: Parameter Arrays and FormatExceptions");
       Console.WriteLine("22: Examples: Format a single argument");
       Console.WriteLine("23: Examples: Format two arguments");
       Console.WriteLine("24: Examples: Format three arguments");
       Console.WriteLine("25: Examples: Format more than three arguments #1");
       Console.WriteLine("26: Examples: Format more than three arguments #2");
       Console.WriteLine("27: Examples: Culture-sensitive formatting");

       if (! String.IsNullOrEmpty(msg))
          Console.WriteLine($"\n** {msg} **\n");

       Console.Write("\nEnter the number of the example you wish to run and press <Enter>, or 0 to Exit: ");
       var choice = Console.ReadLine(); 
       return choice;
    }


}