﻿using System;

namespace conversions
{
    class Program
    {
        static void Main(string[] args)
        {
            StringToDateTime.Examples();
        }
    }
}
