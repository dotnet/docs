Imports System.Collections.Generic
Imports System.Globalization

Module ParseExamples
    Private examples As KeyValuePair(Of String, Action)()
    Private msg As String = Nothing
    
    Sub New()
       examples = {
          New KeyValuePair(Of String, Action)(" 1. Forms of the string to be parsed", AddressOf Strings.Parse),
          New KeyValuePair(Of String, Action)(" 2. Return value: The DateTime.Kind property", AddressOf ReturnValue.Kind),
          New KeyValuePair(Of String, Action)(" 3. StyleFlags.RoundtripKind: Round-tripping a DateTime value", 
                                              AddressOf StyleFlag.RoundtripKind),
          New KeyValuePair(Of String, Action)(" 4. DateTime.Parse(String) overload", 
                                              AddressOf DateTimeParse1.ParseWithSingleArg), 
          New KeyValuePair(Of String, Action)(" 5. DateTime.Parse(String, IFormatProvider) overload", 
                                              AddressOf DateTimeParse2.ParseWithTwoArgs), 
          New KeyValuePair(Of String, Action)(" 6. DateTime.Parse(String, IFormatProvider, DatTimeStyles) overload", 
                                              AddressOf DateTimeParse3.ParseWithThreeArgs) } 
    End Sub

    Public Sub Main()
       Do
           Dim choice = GetSelection(msg)
           ' Make sure this parses.
           Dim nChoice As Integer
           Dim result = Int32.TryParse(choice, nChoice)
           msg = ""

           If Not result Then
              msg = $"'{choice}' is not a number between 0 and {examples.Length}."
           Else
              If nChoice = 0 Then
                   Return
              ElseIf nChoice < 0 OrElse nChoice > examples.Length Then
                 msg = $"Your selection must be between 0 and {examples.Length}."
              Else
                   nChoice -= 1
                   Dim exampleToRun As Action = examples(nChoice).Value
                   exampleToRun()
                   
                   Console.Write(vbCrLf + "Press any key to continue...")
                   Console.ReadKey(false)
               End If
            End If    
        Loop
    End Sub 

    Private Function GetSelection(msg As String) As String
       Console.Clear()
       Console.WriteLine()
       For Each example in examples
          Console.WriteLine(example.Key)
       Next 

       If Not String.IsNullOrEmpty(msg) Then _
          Console.WriteLine($"{vbCrLf}** {msg} **{vbCrLf}")

       Console.Write($"{vbCrLf}Enter the number of the example you wish to run and press <Enter>, or 0 to Exit: ")
       Dim choice = Console.ReadLine() 
       Return choice
    End Function
End Module
