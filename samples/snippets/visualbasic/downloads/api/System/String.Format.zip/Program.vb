Imports System.Collections.Generic
Imports System.Globalization

Module FormatExamplesMain
    Private examples As KeyValuePair(Of String, Action)()

    Sub New()
       examples = {
          new KeyValuePair(Of String, Action)(" 1. Get Started: Insert an object into a string", addressof GetStarted.Example1),
          new KeyValuePair(Of String, Action)(" 2. Get Started: Inserting a formatted object into a string", addressof GetStarted.Example2),
          new KeyValuePair(Of String, Action)(" 3. Get Started: Format item and object", addressof GetStarted.Example3),
          new KeyValuePair(Of String, Action)(" 4. Get Started: 2 format items and 2 objects", addressof GetStarted.Example4),
          new KeyValuePair(Of String, Action)(" 5. Get Started: Control formatting", addressof GetStarted.Example5),
          new KeyValuePair(Of String, Action)(" 6. Get Started: Control spacing", addressof GetStarted.Example6),
          new KeyValuePair(Of String, Action)(" 7: Get Started: Control alignment", addressof GetStarted.Example7),
          new KeyValuePair(Of String, Action)(" 8: Format Elements: in brief", addressof FormatElements.FormatMethod),
          new KeyValuePair(Of String, Action)(" 9: Format Elements: format item", addressof FormatElements.FormatItem),
          new KeyValuePair(Of String, Action)("10: Format Elements: Formatted format item", addressof FormatElements.FormattedFormatItem),
          new KeyValuePair(Of String, Action)("11: Format Elements: Format items with the same index", addressof FormatElements.SameIndex),
          new KeyValuePair(Of String, Action)("12: Custom Formatting: Customer account formatter", addressof CustomerFormatterTest.Test),
          new KeyValuePair(Of String, Action)("13: Custom Formatting: Roman numeral formatter", addressof RomanNumeralExample.Test),
          new KeyValuePair(Of String, Action)("14: Q & A: String interpolation comparison", addressof QA.WithoutInterpolation),
          new KeyValuePair(Of String, Action)("15: Q & A: Digits after the decimal separator", addressof QA.DecimalDigits),
          new KeyValuePair(Of String, Action)("16: Q & A: Digits after the decimal separator with custom format string",  
                                              addressof QA.DigitsUsingCustomFormatSpecifier),
          new KeyValuePair(Of String, Action)("17: Q & A: Integral digits", addressof QA.IntegralDigits),
          new KeyValuePair(Of String, Action)("18: Q & A: Integral digits with a custom format string", addressof QA.IntegralDigitsUsingCustom), 
          new KeyValuePair(Of String, Action)("19: Q & A: Escaped braces", addressof QA.EscapedBraces),
          new KeyValuePair(Of String, Action)("20: Q & A: Braces in a format list", addressof QA.BracesInFormatList),
          new KeyValuePair(Of String, Action)("21: Q & A: Parameter Arrays and FormatExceptions", addressof QA.FormatException),
          new KeyValuePair(Of String, Action)("22: Examples: Format a single argument", addressof FormatExamples.SingleArgument),
          new KeyValuePair(Of String, Action)("23: Examples: Format two arguments", addressof FormatExamples.TwoArguments),
          new KeyValuePair(Of String, Action)("24: Examples: Format three arguments", addressof FormatExamples.ThreeArguments),
          new KeyValuePair(Of String, Action)("25: Examples: Format more than three arguments #1", addressof FormatExamples.MoreThanThree_1),
          new KeyValuePair(Of String, Action)("26: Examples: Format more than three arguments #2", addressof FormatExamples.MoreThanThree_2),
          new KeyValuePair(Of String, Action)("27: Examples: Culture-sensitive formatting", addressof FormatExamples.CultureSensitive) }
    End Sub

    Public Sub Main()
       Do
           Dim choice = GetSelection("")
 
           ' Make sure this parses.
           Dim nChoice As Integer
           Dim result = Int32.TryParse(choice, nChoice)
           Dim msg As String

           If Not result Then
              msg = $"'{choice}' is not a number between 0 and {examples.Length}."
              GetSelection(msg)
           End If

           If nChoice < 0 OrElse nChoice > examples.Length Then
              msg = $"Your selection must be between 0 and {examples.Length}."
              GetSelection(msg)
           End If
           Console.WriteLine()

            If nChoice = 0 Then
                Return
            Else
                nChoice -= 1
                Dim exampleToRun As Action = examples(nChoice).Value
                exampleToRun()
            End If 

            Console.Write(vbCrLf + "Press any key to continue...")
            Console.ReadKey(false)
        Loop
    End Sub 

    Private Function GetSelection(msg As String) As String
       Console.Clear()
       For Each example in examples
          Console.WriteLine(example.Key)
       Next 

       If Not String.IsNullOrEmpty(msg) Then _
          Console.WriteLine($"{vbCrLf}** {msg} **{vbCrLf}")

       Console.Write($"{vbCrLf}Enter the number of the example you wish to run and press <Enter>, or 0 to Exit: ")
       Dim choice = Console.ReadLine() 
       Return choice
    End Function
End Module
