Imports System.Collections.Generic

Public Module FormatExamples
    Public Sub SingleArgument()
        Dim birthdate As Date = #7/28/1993#
        Dim dates() As Date = { #9/16/1993#, #7/28/1994#, #10/16/2000#, _
                                #7/27/2003#, #5/27/2007# }
        For Each dateValue As Date In dates
            Dim interval As TimeSpan = dateValue - birthdate
            ' Get the approximate number of years, without accounting for leap years.
            Dim years As Integer = CInt(interval.TotalDays) \ 365
            ' See if adding the number of years exceeds dateValue.
            Dim output As String
            If birthdate.AddYears(years) <= dateValue Then
                output = String.Format("You are now {0} years old.", years)
                Console.WriteLine(output)
            Else
                output = String.Format("You are now {0} years old.", years - 1)
                Console.WriteLine(output)   
            End If
        Next
   End Sub
    ' The example displays the following output:
    '       You are now 0 years old.
    '       You are now 1 years old.
    '       You are now 7 years old.
    '       You are now 9 years old.
    '       You are now 13 years old.

    Public Sub TwoArguments()
        Dim temperatureInfo As New Dictionary(Of Date, Double) 
        temperatureInfo.Add(#6/1/2010 2:00PM#, 87.46)
        temperatureInfo.Add(#12/1/2010 10:00AM#, 36.81)
        
        Console.WriteLine("Temperature Information:")
        Console.WriteLine()
        Dim output As String   
        For Each item In temperatureInfo
            output = String.Format("Temperature at {0,8:t} on {0,9:d}: {1,5:N1}°F", _
                                    item.Key, item.Value)
            Console.WriteLine(output)
        Next
    End Sub
    ' The example displays the following output:
    '       Temperature Information:
    '       
    '       Temperature at  2:00 PM on  6/1/2010:  87.5°F
    '       Temperature at 10:00 AM on 12/1/2010:  36.8°F

   
    Public Sub ThreeArguments()
        Dim formatString As String = "    {0,10} ({0,8:X8})" + vbCrLf +  _
                                     "And {1,10} ({1,8:X8})" + vbCrLf + _
                                     "  = {2,10} ({2,8:X8})"
        Dim value1 As Integer = 16932
        Dim value2 As Integer = 15421
        Dim result As String = String.Format(formatString, _
                                             value1, value2, value1 And value2)
        Console.WriteLine(result)                          
    End Sub
    ' The example displays the following output:
    '                16932 (00004224)
    '       And      15421 (00003C3D)
    '         =         36 (00000024)

    Public Sub MoreThanThree_1()
        Dim date1 As Date = #7/1/2009#
        Dim hiTime As New TimeSpan(14, 17, 32)
        Dim hiTemp As Decimal = 62.1d 
        Dim loTime As New TimeSpan(3, 16, 10)
        Dim loTemp As Decimal = 54.8d 

        Dim result1 As String = String.Format("Temperature on {0:d}:{5}{1,11}: {2} degrees (hi){5}{3,11}: {4} degrees (lo)", _
                                              date1, hiTime, hiTemp, loTime, loTemp, vbCrLf)
        Console.WriteLine(result1)
        Console.WriteLine()
            
        Dim result2 As String = String.Format("Temperature on {0:d}:{5}{1,11}: {2} degrees (hi){5}{3,11}: {4} degrees (lo)", _
                                               New Object() { date1, hiTime, hiTemp, loTime, loTemp, vbCrLf })
        Console.WriteLine(result2)                                            
    End Sub
    ' The example displays the following output:
    '       Temperature on 7/1/2009:
    '          14:17:32: 62.1 degrees (hi)
    '          03:16:10: 54.8 degrees (lo)
    '
    '       Temperature on 7/1/2009:
    '          14:17:32: 62.1 degrees (hi)
    '          03:16:10: 54.8 degrees (lo)


    Public Class CityInfo
        Public Sub New(name As String, population As Integer, area As Decimal, year As Integer)
            Me.Name = name
            Me.Population = population
            Me.Area = area
            Me.Year = year
        End Sub
        
        Public ReadOnly Name As String
        Public ReadOnly Population As Integer
        Public ReadOnly Area As Decimal
        Public ReadOnly Year As Integer
    End Class
    
    Public Sub MoreThanThree_2()
        Dim nyc2010 As New CityInfo("New York", 8175133, 302.64d, 2010)
        ShowPopulationData(nyc2010)
        Dim sea2010 As New CityInfo("Seattle", 608660, 83.94d, 2010)      
        ShowPopulationData(sea2010) 
    End Sub
   
    Private Sub ShowPopulationData(city As CityInfo)
        Dim args() As Object = { city.Name, city.Year, city.Population, city.Area }
        Dim result = String.Format("{0} in {1}: Population {2:N0}, Area {3:N1} sq. feet", args)
        Console.WriteLine(result) 
    End Sub
    ' The example displays the following output:
    '       New York in 2010: Population 8,175,133, Area 302.6 sq. feet
    '       Seattle in 2010: Population 608,660, Area 83.9 sq. feet   

    Public Sub CultureSensitive()
        Dim cultureNames() As String = { "en-US", "fr-FR", "de-DE", "es-ES" }
        
        Dim dateToDisplay As Date = #9/1/2009 6:32PM#
        Dim value As Double = 9164.32

        Console.WriteLine("Culture     Date                                Value")
        Console.WriteLine()      
        For Each cultureName As String In cultureNames
            Dim culture As New System.Globalization.CultureInfo(cultureName)
            Dim output As String = String.Format(culture, "{0,-11} {1,-35:D} {2:N}", _
                                                culture.Name, dateToDisplay, value)
            Console.WriteLine(output)
        Next    
   End Sub
    ' The example displays the following output:
    '       Culture     Date                                Value
    '       
    '       en-US       Tuesday, September 01, 2009         9,164.32
    '       fr-FR       mardi 1 septembre 2009              9 164,32
    '       de-DE       Dienstag, 1. September 2009         9.164,32
    '       es-ES       martes, 01 de septiembre de 2009    9.164,32
End Module