
Public Module GetStarted
    Public Sub Example1()
        Dim pricePerOunce As Decimal = 17.36d
        Dim s As String = String.Format("The current price is {0} per ounce.",
                                        pricePerOunce)
        Console.WriteLine(s)
        ' Result: The current price is 17.36 per ounce.
    End Sub

    Public Sub Example2()
        Dim pricePerOunce As Decimal = 17.36d
        Dim s As String = String.Format("The current price is {0:C2} per ounce.",
                                        pricePerOunce)
        Console.WriteLine(s)
        ' Result if current culture is en-US:
        '      The current price is $17.36 per ounce.    } 
    End Sub

    Public Sub Example3()
        Dim temp As Decimal = 20.4d
        Dim s As String = String.Format("The temperature is {0}°C.", temp)
        Console.WriteLine(s)
        ' Displays 'The temperature is 20.4°C.'
    End Sub

    Public Sub Example4()
        Dim s As String = String.Format("At {0}, the temperature is {1}°C.",
                                        Date.Now, 20.4)
        Console.WriteLine(s)
        ' Output similar to: 'At 4/10/2015 9:29:41 AM, the temperature is 20.4°C.'
    End Sub

    Public Sub Example5()
        Dim s As String = String.Format("It is now {0:d} at {0:t}",
                                        Date.Now)
        Console.WriteLine(s)
        ' Output similar to: 'It is now 4/10/2015 at 10:04 AM'
    End Sub

    Public Sub Example6()
        Dim years() As Integer = { 2013, 2014, 2015 }
        Dim population() As Integer  = { 1025632, 1105967, 1148203 }
        Dim sb As New System.Text.StringBuilder()
        sb.Append(String.Format("{0,6} {1,15}{2}{2}",
                                "Year", "Population", vbCrLf))
        For index As Integer = 0 To years.Length - 1
        sb.AppendFormat("{0,6} {1,15:N0}{2}",
                        years(index), population(index), vbCrLf)
        Next
        Console.WriteLine(sb.ToString())
        ' Result:
        '      Year      Population
        '
        '      2013       1,025,632
        '      2014       1,105,967
        '      2015       1,148,203
    End Sub

    Public Sub Example7()
        Dim years() As Integer = { 2013, 2014, 2015 }
        Dim population() As Integer  = { 1025632, 1105967, 1148203 }
        Dim s As String = String.Format("{0,-10} {1,-10}{2}{2}",
                                        "Year", "Population", vbCrLf)
        For index As Integer = 0 To years.Length - 1
        s += String.Format("{0,-10} {1,-10:N0}{2}",
                            years(index), population(index), vbCrLf)
        Next
        Console.WriteLine(s)
        ' Result:
        '    Year       Population
        '
        '    2013       1,025,632
        '    2014       1,105,967
        '    2015       1,148,203
    End Sub
End Module
